const mongoose = require('mongoose');

const swapRequestSchema = new mongoose.Schema({
  fromUser: String,
  toUser: String,
  skillsExchanged: [String],
  status: { type: String, enum: ['pending', 'accepted', 'rejected'], default: 'pending' },
  timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model('SwapRequest', swapRequestSchema);
