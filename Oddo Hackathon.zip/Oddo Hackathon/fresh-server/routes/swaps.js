const express = require('express');
const router = express.Router();
const SwapRequest = require('../models/SwapRequest');

router.get('/', async (req, res) => {
  const swaps = await SwapRequest.find();
  res.json(swaps);
});

router.post('/', async (req, res) => {
  const newSwap = new SwapRequest(req.body);
  await newSwap.save();
  res.json(newSwap);
});

module.exports = router;
