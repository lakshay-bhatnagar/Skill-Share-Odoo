let allUsers = []; // store all users globally

document.addEventListener("DOMContentLoaded", function () {
  fetch("http://localhost:5000/api/users")
    .then((res) => res.json())
    .then((users) => {
      allUsers = users;
      renderProfiles(allUsers);
    })
    .catch((err) => {
      console.error("❌ Failed to fetch users:", err);
    });

  // search input event
  const searchInput = document.getElementById("searchInput");
  searchInput.addEventListener("input", function () {
    const query = searchInput.value.toLowerCase();

    const filtered = allUsers.filter((user) =>
      [...user.skillsOffered, ...user.skillsWanted]
        .join(" ")
        .toLowerCase()
        .includes(query)
    );

    renderProfiles(filtered);
  });
});

// render function
function renderProfiles(users) {
  const container = document.querySelector(".profile-list") || document.getElementById("profileList");
  container.innerHTML = "";

  users.forEach((user) => {
    const card = document.createElement("div");
    card.className = "profile-card";
    card.innerHTML = `
      <div class="profile-left" style="cursor:pointer;" onclick="window.location.href='user.html?id=${user._id}'">
        <div class="profile-photo">
        <img src="../asset/profile1.jpg" alt="Profile Picture" class="profile-pic">
        </div>
        <div>
          <h3>${user.name}</h3>
          <div class="skills">
            <strong>Offers:</strong>
            ${user.skillsOffered.map((skill) => `<span>${skill}</span>`).join(" ")}
          </div>
          <div class="skills">
            <strong>Wants:</strong>
            ${user.skillsWanted.map((skill) => `<span>${skill}</span>`).join(" ")}
          </div>
          <p><strong>Availability:</strong> ${user.availability}</p>
          <p><strong>Location:</strong> ${user.location}</p>
        </div>
      </div>
      <button class="request-btn" onclick="event.stopPropagation(); openSwapPopup('${user._id}')">Request Swap</button>
    `;
    container.appendChild(card);
  });
}

function openSwapPopup(userId) {
  const selectedUser = allUsers.find(u => u._id === userId);
  if (!selectedUser) return alert("User not found.");

  const popup = document.createElement("div");
  popup.className = "popup-overlay";
  popup.innerHTML = `
    <div class="popup">
      <h2>Request Swap with ${selectedUser.name}</h2>

      <label>Your Offered Skill:</label>
      <select id="offeredSkill">
        ${selectedUser.skillsWanted.map(skill => `<option value="${skill}">${skill}</option>`).join('')}
      </select>

      <label>Their Wanted Skill:</label>
      <select id="wantedSkill">
        ${selectedUser.skillsOffered.map(skill => `<option value="${skill}">${skill}</option>`).join('')}
      </select>

      <label>Message:</label>
      <textarea id="swapMessage" rows="4" placeholder="Write a short message..."></textarea>

      <div style="margin-top: 10px;">
        <button onclick="submitSwapRequest('${userId}', '${selectedUser.name}')">Submit</button>
        <button onclick="closePopup()">Cancel</button>
      </div>
    </div>
  `;
  document.body.appendChild(popup);
}

function closePopup() {
  const existing = document.querySelector(".popup-overlay");
  if (existing) existing.remove();
}

function submitSwapRequest(userId, userName) {
  const offeredSkill = document.getElementById("offeredSkill").value;
  const wantedSkill = document.getElementById("wantedSkill").value;
  const message = document.getElementById("swapMessage").value;

  // later connect to backend using fetch()
  console.log("Request Sent To:", userId);
  console.log("Your Offered:", offeredSkill);
  console.log("You Want:", wantedSkill);
  console.log("Message:", message);

  closePopup();
  showConfirmation(userName);
}

function showConfirmation(userName) {
  const confirmBox = document.createElement("div");
  confirmBox.className = "popup-overlay";
  confirmBox.innerHTML = `
    <div class="popup" style="text-align:center;">
      <h2>Swap Request Sent ✅</h2>
      <p>Your request to <strong>${userName}</strong> has been submitted!</p>
      <button onclick="closePopup()">OK</button>
    </div>
  `;
  document.body.appendChild(confirmBox);
}

// CSS for popup - inject dynamically
const style = document.createElement('style');
style.innerHTML = `
.popup-overlay {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
}
.popup {
  background: white;
  padding: 25px;
  border-radius: 10px;
  width: 400px;
  max-width: 90%;
  box-shadow: 0 5px 15px rgba(0,0,0,0.3);
}
.popup h2 {
  margin-top: 0;
}
.popup textarea,
.popup select {
  width: 100%;
  padding: 10px;
  margin-top: 5px;
  margin-bottom: 15px;
  border-radius: 6px;
  border: 1px solid #ccc;
  font-size: 14px;
}
.popup button {
  padding: 10px 15px;
  margin-right: 10px;
  border: none;
  border-radius: 6px;
  font-weight: bold;
  cursor: pointer;
}
.popup button:first-of-type {
  background-color: #4db6ac;
  color: white;
}
.popup button:last-of-type {
  background-color: #ccc;
}
`;
document.head.appendChild(style);
function openSwapPopup(userId) {
  const selectedUser = allUsers.find(u => u._id === userId);
  if (!selectedUser) return alert("User not found.");

  const popup = document.createElement("div");
  popup.className = "popup-overlay";
  popup.innerHTML = `
    <div class="popup">
      <h2>Request Swap with ${selectedUser.name}</h2>
      
      <label>Your Offered Skill:</label>
      <select id="offeredSkill">
        ${selectedUser.skillsWanted.map(skill => `<option value="${skill}">${skill}</option>`).join('')}
      </select>

      <label>Their Wanted Skill:</label>
      <select id="wantedSkill">
        ${selectedUser.skillsOffered.map(skill => `<option value="${skill}">${skill}</option>`).join('')}
      </select>

      <label>Message:</label>
      <textarea id="swapMessage" rows="4" placeholder="Write a short message..."></textarea>

      <div style="margin-top: 10px;">
        <button onclick="submitSwapRequest('${userId}', '${selectedUser.name}')">Submit</button>
        <button onclick="closePopup()">Cancel</button>
      </div>
    </div>
  `;
  document.body.appendChild(popup);
}

function closePopup() {
  const existing = document.querySelector(".popup-overlay");
  if (existing) existing.remove();
}

function submitSwapRequest(userId, userName) {
  const offeredSkill = document.getElementById("offeredSkill").value;
  const wantedSkill = document.getElementById("wantedSkill").value;
  const message = document.getElementById("swapMessage").value;

  const requestData = {
    toUser: userId,
    fromUser: "your_logged_in_user_id_here", // Replace with actual ID
    offeredSkill,
    wantedSkill,
    message
  };

  fetch("http://localhost:5000/api/swaps", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(requestData)
  })
    .then(res => res.json())
    .then(data => {
      closePopup();
      showConfirmation(userName);
    })
    .catch(err => {
      console.error("Swap failed:", err);
      alert("Failed to send request.");
    });
}

function showConfirmation(userName) {
  const confirmBox = document.createElement("div");
  confirmBox.className = "popup-overlay";
  confirmBox.innerHTML = `
    <div class="popup" style="text-align:center;">
      <h2>Swap Request Sent ✅</h2>
      <p>Your request to <strong>${userName}</strong> has been submitted!</p>
      <button onclick="closePopup()">OK</button>
    </div>
  `;
  document.body.appendChild(confirmBox);
}
