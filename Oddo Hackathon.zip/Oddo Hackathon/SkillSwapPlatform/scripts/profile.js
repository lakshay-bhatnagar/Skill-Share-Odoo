function saveProfile() { alert('Profile saved (mock)'); }
function discardChanges() { alert('Changes discarded'); }