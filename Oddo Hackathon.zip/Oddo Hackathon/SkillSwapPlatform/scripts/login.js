document.getElementById('loginForm').addEventListener('submit', async function (e) {
    e.preventDefault();
  
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const errorBox = document.getElementById('loginError');
  
    try {
      const response = await fetch('http://localhost:5000/api/users/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
  
      const result = await response.json();
  
      if (response.ok) {
        localStorage.setItem('loggedInUser', JSON.stringify(result.user));
        window.location.href = 'index.html';
      } else {
        errorBox.textContent = result.message || 'Login failed';
      }
    } catch (err) {
      console.error('Login error:', err);
      errorBox.textContent = 'Server error';
    }
  });
  