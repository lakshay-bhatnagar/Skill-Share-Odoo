const mongoose = require('mongoose');

const SwapRequestSchema = new mongoose.Schema({
  from: String,
  to: String,
  status: {
    type: String,
    enum: ['pending', 'accepted', 'rejected'],
    default: 'pending'
  },
  message: String
});

module.exports = mongoose.model('SwapRequest', SwapRequestSchema);
